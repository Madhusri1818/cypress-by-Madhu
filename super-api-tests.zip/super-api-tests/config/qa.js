export default{
    baseurl: 'https://gorest.co.in/public/v2/'
}